import pyglet
import game
import random

class Obstacle(game.physicalobject.PhysicalObject):
	def __init__(self, *args, **kwargs):
		super(Obstacle, self).__init__( *args, **kwargs)

	
		
	